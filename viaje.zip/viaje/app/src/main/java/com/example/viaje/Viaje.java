package com.example.viaje;

public class Viaje {
}
